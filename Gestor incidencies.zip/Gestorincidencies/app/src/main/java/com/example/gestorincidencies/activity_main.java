package com.example.gestorincidencies;

import android.app.Activity;

public class activity_main extends Activity {
}
